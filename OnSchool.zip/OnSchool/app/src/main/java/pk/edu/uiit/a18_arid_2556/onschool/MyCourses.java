package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MyCourses extends AppCompatActivity {
 ImageButton btnMad;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_courses);
        btnMad = (ImageButton) findViewById(R.id.btnMAD);
        btnMad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyCourses.this,MAD.class);
                startActivity(intent);
            }
        });
    }
}