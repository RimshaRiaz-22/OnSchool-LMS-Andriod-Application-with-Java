package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class profile extends AppCompatActivity {

    EditText etName,etPhone,etCnic,etEmail,etPermanentAddress,etResidentialAddress,etSkill,
            etCountry,etRegion,etExperience,etAdditionalDetails,etDegree,etLevel;
    Button saveBtn;
    String degree,level;
    String user_type;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        initialize();
        Intent intent = getIntent();
        user_type = intent.getStringExtra("user_type");
        Log.d("TAG","From intent" + user_type);

//timepicker
        DatePicker simpleDatePicker = (DatePicker)findViewById(R.id.simpleDatePicker); // initiate a date picker
        simpleDatePicker.setSpinnersShown(true);
        simpleDatePicker.getDayOfMonth();
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserData();
            }
        });

    }

    private void saveUserData() {

        String name = etName.getText().toString();
        String degree = etDegree.getText().toString();
        String level = etLevel.getText().toString();
        String phone = etPhone.getText().toString();
        String cnic = etCnic.getText().toString();
        String email = etEmail.getText().toString();
        String permanentAddress = etPermanentAddress.getText().toString();
        String residentialAddress = etResidentialAddress.getText().toString();
        String skill = etSkill.getText().toString();
        String country = etCountry.getText().toString();
        String experience = etCountry.getText().toString();
        String additionalDetails = etCountry.getText().toString();
        String region = etRegion.getText().toString();
        if(name.isEmpty()){
            etName.setError("Name is required");
            etName.requestFocus();
            return;
        }
        if(phone.isEmpty()){
            etPhone.setError("Phone is required");
            etPhone.requestFocus();
            return;
        }
        if(cnic.isEmpty()){
            etCnic.setError("Cnic is required");
            etCnic.requestFocus();
            return;
        }
        if(email.isEmpty()){
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        }
        if(permanentAddress.isEmpty()){
            etPermanentAddress.setError("Permanent Address is required");
            etPermanentAddress.requestFocus();
            return;
        }
        if(residentialAddress.isEmpty()){
            etResidentialAddress.setError("Residential Address is required");
            etResidentialAddress.requestFocus();
            return;
        }
        if(skill.isEmpty()){
            etSkill.setError("Skill is required");
            etSkill.requestFocus();
            return;
        }
        if(experience.isEmpty()){
            etExperience.setError("Experience is required");
            etExperience.requestFocus();
            return;
        }
        if(additionalDetails.isEmpty()){
            etAdditionalDetails.setError("Additional Detail is required");
            etAdditionalDetails.requestFocus();
            return;
        }
        if(country.isEmpty()){
            etCountry.setError("Country is required");
            etCountry.requestFocus();
            return;
        }
        if(degree.isEmpty()){
            etCountry.setError("Degree is required");
            etCountry.requestFocus();
            return;
        }
        if(degree.isEmpty()){
            etCountry.setError("Level is required");
            etCountry.requestFocus();
            return;
        }
        if(user_type.equals("Student")){
            Student student = new Student(name,phone,cnic,email,degree,level,permanentAddress,
                    residentialAddress, skill,country,experience,additionalDetails,region);
            FirebaseDatabase.getInstance().getReference("Students")
                    .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                    .setValue(student).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), "Data has been filled", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(),Home.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getApplicationContext(), "Data Insertion Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }

    private void initialize() {
        auth = FirebaseAuth.getInstance();
        etName = (EditText) findViewById(R.id.name);
        etPhone = (EditText) findViewById(R.id.phone);
        etCnic = (EditText) findViewById(R.id.cnic);
        etEmail = (EditText) findViewById(R.id.appemail);
        etDegree = (EditText) findViewById(R.id.degree);
        etLevel = (EditText) findViewById(R.id.level);
        etPermanentAddress = (EditText) findViewById(R.id.P_address);
        etResidentialAddress = (EditText) findViewById(R.id.R_address);
        etSkill = (EditText) findViewById(R.id.skill);
        etCountry = (EditText) findViewById(R.id.country);
        etExperience = (EditText) findViewById(R.id.experience);
        etAdditionalDetails = (EditText) findViewById(R.id.additionalDetails);
        etRegion = (EditText) findViewById(R.id.region);
        saveBtn = (Button) findViewById(R.id.saveBtn);
    }
}