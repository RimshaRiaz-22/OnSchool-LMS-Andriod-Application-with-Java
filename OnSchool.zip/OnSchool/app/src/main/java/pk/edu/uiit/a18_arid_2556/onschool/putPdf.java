package pk.edu.uiit.a18_arid_2556.onschool;

public class putPdf{
        public String name;
        public String url;
        public putPdf(){

        }
        public putPdf(String name,String url){
            this.name = name;
            this.url = url;
        }
        public String getName(){
            return name;
        }
        public void setName(String Name){
            this.name = name;
        }
        public String getUrl(){
            return url;
        }
        public void setUrl(String url){
            this.url = url;
        }
}
