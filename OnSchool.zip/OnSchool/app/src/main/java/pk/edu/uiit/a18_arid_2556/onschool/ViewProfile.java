package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import pk.edu.uiit.a18_arid_2556.onschool.databinding.ActivityViewProfileBinding;

public class ViewProfile extends AppCompatActivity {

    private FirebaseUser user;
    private DatabaseReference reference;
    private String userID;
    TextView Email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);
        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Students");
        userID = user.getUid();
        final TextView nameTextView =(TextView) findViewById(R.id.UserName);
        final TextView emailTextView =(TextView) findViewById(R.id.emailId);
        final TextView phoneTextView =(TextView) findViewById(R.id.phone);
        final TextView cnicTextView =(TextView) findViewById(R.id.cnic);
        final TextView addressTextView =(TextView) findViewById(R.id.address);
        final TextView degreeTextView =(TextView) findViewById(R.id.degree);
        final TextView studyTextView =(TextView) findViewById(R.id.studyl);
        reference.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Student userProfile =snapshot.getValue(Student.class);
                if(userProfile != null){
                    String UserName = userProfile.name;
                    String emailId = userProfile.email;
                    String phone = userProfile.phone;
                    String cnic = userProfile.cnic;
                    String address = userProfile.permanentAddress;
                    String degree = userProfile.degree;
                    String studyl = userProfile.level;

                            nameTextView.setText(UserName);
                            emailTextView.setText(emailId);
                            phoneTextView.setText(phone);
                            cnicTextView.setText(cnic);
                            addressTextView.setText(address);
                            degreeTextView.setText(degree);
                            studyTextView.setText(studyl);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ViewProfile.this,"Somethimg wrong happened!",Toast.LENGTH_LONG).show();
            }
        });

    }
}