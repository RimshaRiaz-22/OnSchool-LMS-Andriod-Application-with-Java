package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Signup extends AppCompatActivity {
Button btnsgnup;
TextView sig;
FirebaseAuth auth,checkUserAuth;
EditText etEmail,etPassword,etConfirmPassword,etUserType;
String user_type; //Teacher or Student
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        checkUserAuth = FirebaseAuth.getInstance();
        if(checkUserAuth.getCurrentUser() != null){
            Intent intent = new Intent(getApplicationContext(),Home.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }else {

            btnsgnup = (Button) findViewById(R.id.signup);
            sig = (TextView) findViewById(R.id.tv2);
            etEmail = (EditText) findViewById(R.id.email);
            etPassword = (EditText) findViewById(R.id.pass);
            etUserType = (EditText) findViewById(R.id.userType);
            etConfirmPassword = (EditText) findViewById(R.id.cpass);
            auth = FirebaseAuth.getInstance();


            btnsgnup.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    signupUser();
                }
            });

            sig.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Signup.this, MainActivity.class);
                    startActivity(intent);
                }
            });
        }
    }

    private void signupUser() {
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        user_type = etUserType.getText().toString();
        String confirmPassword = etConfirmPassword.getText().toString();
        if(email.isEmpty()){
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            return;
        }
        if(password.isEmpty()){
            etPassword.setError("Password is required");
            etPassword.requestFocus();
            return;
        }
        if(confirmPassword.isEmpty()){
            etConfirmPassword.setError("Confirm the Password");
            etConfirmPassword.requestFocus();
            return;
        }
        if(user_type.isEmpty()){
            etConfirmPassword.setError("Choose either teacher or student");
            etConfirmPassword.requestFocus();
            return;
        }

        auth.createUserWithEmailAndPassword(email,password)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                            Intent intent=new Intent(Signup.this,profile.class);
                            intent.putExtra("user_type",user_type);
                            startActivity(intent);
                        }else{
                            Toast.makeText(getApplicationContext(), "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

    }

}