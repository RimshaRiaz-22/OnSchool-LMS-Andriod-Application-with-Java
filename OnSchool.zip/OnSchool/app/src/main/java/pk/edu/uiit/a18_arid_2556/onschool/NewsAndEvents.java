package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class NewsAndEvents extends AppCompatActivity implements View.OnClickListener{
   Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_and_events);
        btn =(Button) findViewById(R.id.btn);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.btn){
            getSupportFragmentManager().beginTransaction().replace(R.id.container,new NewsFragment()).commit();
            btn.setVisibility(View.GONE);
        }
    }
}