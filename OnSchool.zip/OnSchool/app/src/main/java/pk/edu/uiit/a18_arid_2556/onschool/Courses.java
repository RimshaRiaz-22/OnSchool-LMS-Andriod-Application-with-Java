package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Courses extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);
    }
}