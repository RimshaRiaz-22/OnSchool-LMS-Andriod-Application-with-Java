package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class quizActivity extends AppCompatActivity {
    private TextView quesstionTV,questionNumberTV;
    private Button option1Btn,option2Btn,option3Btn,option4Btn;
    private ArrayList<QuizModal> quizModalArrayList;
    Random random;
    int currentScore = 0,questionAttempted =1,currentPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        quesstionTV =findViewById(R.id.heading);
        questionNumberTV =findViewById(R.id.idTVQuestionAttempted);
        option1Btn =findViewById(R.id.Option1);
        option2Btn =findViewById(R.id.Option2);
        option3Btn =findViewById(R.id.Option3);
        option4Btn =findViewById(R.id.Option4);
        quizModalArrayList =new ArrayList<>();
        random = new Random();
        getQuizQuestion(quizModalArrayList);
        currentPos =random.nextInt(quizModalArrayList.size());
        setDataToViews(currentPos);
        option1Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option1Btn.getText().toString().trim().toLowerCase())){
                    currentScore++;
                }
                questionAttempted++;
                currentPos=random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        option2Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option2Btn.getText().toString().trim().toLowerCase())){
                    currentScore++;
                }
                questionAttempted++;
                currentPos=random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        option3Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option3Btn.getText().toString().trim().toLowerCase())){
                    currentScore++;
                }
                questionAttempted++;
                currentPos=random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });
        option4Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(quizModalArrayList.get(currentPos).getAnswer().trim().toLowerCase().equals(option4Btn.getText().toString().trim().toLowerCase())){
                    currentScore++;
                }
                questionAttempted++;
                currentPos=random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
            }
        });

    }
    private void showBottomSheet(){
        BottomSheetDialog bottomSheetDialog =new BottomSheetDialog(quizActivity.this);
        View bottomSheetView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.bottom_score,(LinearLayout)findViewById(R.id.LLQuiz));
        TextView scoreTV = bottomSheetView.findViewById(R.id.idTVScore);
        Button restartQuizBtn =bottomSheetView.findViewById(R.id.idBtnRestart);
        Button exit =bottomSheetView.findViewById(R.id.idBtnExit);
        scoreTV.setText("Your Score is \n"+currentScore+"/10");
        restartQuizBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPos = random.nextInt(quizModalArrayList.size());
                setDataToViews(currentPos);
                questionAttempted = 1;
                currentScore = 0;
                bottomSheetDialog.dismiss();
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(quizActivity.this, Home.class);
                startActivity(intent);
            }
        });
        bottomSheetDialog.setCancelable(false);
        bottomSheetDialog.setContentView(bottomSheetView);
        bottomSheetDialog.show();
    }

    private void setDataToViews(int currentPos) {
        questionNumberTV.setText("Question Attempted :"+questionAttempted+"/10");
        if(questionAttempted == 10){
            showBottomSheet();
        }else{
            quesstionTV.setText(quizModalArrayList.get(currentPos).getQuestion());
            option1Btn.setText(quizModalArrayList.get(currentPos).getOption1());
            option2Btn.setText(quizModalArrayList.get(currentPos).getOption2());
            option3Btn.setText(quizModalArrayList.get(currentPos).getOption3());
            option4Btn.setText(quizModalArrayList.get(currentPos).getOption4());
        }

    }


    private void getQuizQuestion(ArrayList<QuizModal> quizModalArrayList) {
        quizModalArrayList.add(new QuizModal("What method you should override to use Android menu system?","onCreateOptionMenu()","onMenuCreated()","onCreateMenu()","onCreateContextMenu()","onCreateOptionMenu()"));
        quizModalArrayList.add(new QuizModal("What Activity method you use to retrieve a reference to an Android view by using the id attribute of a resource XML?","findViewByReference(int id)","findViewById(int id)","retrieveResourceById(int id)","findViewById(String id)","findViewById(int id)"));
        quizModalArrayList.add(new QuizModal(" Which of the following is not an Android component (i.e. a point from which the system can enter your application)?","Service","Activity","Layout","Content Provider","Layout"));
        quizModalArrayList.add(new QuizModal("During an Activity life-cycle, what is the first callback method invoked by the system?","onStop()","onStart()","onCreate()","onRestore()","onCreate()"));
        quizModalArrayList.add(new QuizModal("What method you should override to use Android menu system?","onCreateOptionMenu()","onMenuCreated()","onCreateMenu()","onCreateContextMenu()","onCreateOptionMenu()"));
        quizModalArrayList.add(new QuizModal("What Activity method you use to retrieve a reference to an Android view by using the id attribute of a resource XML?","findViewByReference(int id)","findViewById(int id)","retrieveResourceById(int id)","findViewById(String id)","findViewById(int id)"));
        quizModalArrayList.add(new QuizModal(" Which of the following is not an Android component (i.e. apoint from which the system can enter your application)?","Service","Activity","Layout","Content Provider","Layout"));
        quizModalArrayList.add(new QuizModal("During an Activity life-cycle, what is the first callback method invoked by the system?","onStop()","onStart()","onCreate()","onRestore()","onCreate()"));

    }
}