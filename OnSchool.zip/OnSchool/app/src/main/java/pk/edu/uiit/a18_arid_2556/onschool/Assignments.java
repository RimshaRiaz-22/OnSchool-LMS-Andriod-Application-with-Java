package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Assignments extends AppCompatActivity {
     Button Select,Select1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignments);
        Select = (Button) findViewById(R.id.Select);
        Select1 = (Button) findViewById(R.id.Select1);
        Select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Assignments.this, UploadFiles.class);
                startActivity(intent);
            }
        });
        Select1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Assignments.this, ViewPdf.class);
                intent.putExtra("pdf_url","https://www.gla.ac.uk/media/Media_383357_smxx.pdf");
                startActivity(intent);
            }
        });
    }
}