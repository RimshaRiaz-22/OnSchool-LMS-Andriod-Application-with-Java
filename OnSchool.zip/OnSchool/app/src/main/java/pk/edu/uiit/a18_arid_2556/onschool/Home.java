package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import com.google.firebase.auth.FirebaseAuth;

public class Home extends AppCompatActivity {
    ImageButton btnlinks, btnasgt, btnquz, btnnots, btnnews,btnclass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        btnlinks = (ImageButton) findViewById(R.id.btnlinks);
        btnasgt = (ImageButton) findViewById(R.id.btnassignments);
        btnquz = (ImageButton) findViewById(R.id.btnquiz);
        btnnots = (ImageButton) findViewById(R.id.btnnotes);
        btnnews = (ImageButton) findViewById(R.id.btnnews);
        btnclass = (ImageButton) findViewById(R.id.btnclass);
        btnclass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, MyCourses.class);
                startActivity(intent);
            }
        });
        btnlinks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, impLinks.class);
                startActivity(intent);
            }
        });
        btnnews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, NewsAndEvents.class);
                startActivity(intent);
            }
        });

        btnasgt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, Assignments.class);
                startActivity(intent);
            }
        });

        btnquz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, Quizs.class);
                startActivity(intent);
            }
        });

        btnnots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Home.this, addNotes.class);
                startActivity(intent);
            }
        });


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.profile) {
            Intent intent = new Intent(Home.this, ViewProfile.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.settings){
            Intent intent = new Intent(Home.this, settings.class);
            startActivity(intent);
            return true;
        }else if(id == R.id.logout){
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(Home.this, Signup.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return true;
        }
    return super.onOptionsItemSelected(item);
    }
}