package pk.edu.uiit.a18_arid_2556.onschool;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CourseContent extends AppCompatActivity {
    ListView listview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_content);
        listview  =(ListView) findViewById(R.id.listview);
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1
                ,getResources().getStringArray(R.array.Lectures));
        listview.setAdapter(myAdapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                intent.putExtra("pdf_url","https://home.cs.colorado.edu/~kena/classes/5448/s11/lectures/11_introtoandroid.pdf");
                startActivity(intent);
                }else if(position==1){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","https://web.stanford.edu/class/cs231m/lectures/lecture-2-android-dev.pdf");
                    startActivity(intent);
                }else if(position==2){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","http://barbra-coco.dyndns.org/student/learning_android_studio.pdf");
                    startActivity(intent);
                }else if(position==3){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","http://projanco.com/Library/Android%20App%20Development%20in%20Android%20Studio%20-%20Java%20plus%20Android%20edition%20for%20beginners.pdf");
                    startActivity(intent);
                }else if(position==4){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","https://web.stanford.edu/class/cs231m/lectures/lecture-2-android-dev.pdf");
                    startActivity(intent);
                }else if(position==5){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","http://barbra-coco.dyndns.org/student/learning_android_studio.pdf");
                    startActivity(intent);
                }else if(position==6){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","http://projanco.com/Library/Android%20App%20Development%20in%20Android%20Studio%20-%20Java%20plus%20Android%20edition%20for%20beginners.pdf");
                    startActivity(intent);
                }else if(position==7){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","https://web.stanford.edu/class/cs231m/lectures/lecture-2-android-dev.pdf");
                    startActivity(intent);
                }else if(position==8){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","http://barbra-coco.dyndns.org/student/learning_android_studio.pdf");
                    startActivity(intent);
                }else if(position==9){
                    Intent intent = new Intent(CourseContent.this, ViewLecture.class);
                    intent.putExtra("pdf_url","http://projanco.com/Library/Android%20App%20Development%20in%20Android%20Studio%20-%20Java%20plus%20Android%20edition%20for%20beginners.pdf");
                    startActivity(intent);
                }
            }
        });
    }
}