package pk.edu.uiit.a18_arid_2556.onschool;

public class Teacher {
    public String name,phone,cnic,email,degree,level,permanentAddress,
            residentialAddress,skill,country,experience,additionalDetails,region;

    Teacher(){

    }

    Teacher(String name,String phone,String cnic,String email,String degree,String level,
            String permanentAddress,String residentialAddress,String skill,String country,
            String experience,String additionalDetails,String region)
    {
        this.name = name;
        this.phone = phone;
        this.cnic = cnic;
        this.email = email;
        this.degree = degree;
        this.level = level;
        this.permanentAddress = permanentAddress;
        this.residentialAddress = residentialAddress;
        this.skill = skill;
        this.country = country;
        this.experience = experience;
        this.additionalDetails = additionalDetails;
    }
}
